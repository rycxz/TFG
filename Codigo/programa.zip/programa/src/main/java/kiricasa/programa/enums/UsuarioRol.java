package kiricasa.programa.enums;

public enum UsuarioRol {
    USER,ADMIN

}
