/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

package kiricasa.programa.enums;

/**
 *
 * @author 6003194
 */
public enum TipoPiso {
    HOMBRES,
    MUJERES,
    MIXTO,
    SOLO
}
